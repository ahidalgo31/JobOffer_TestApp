﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestApp.Entities;
using TestApp.Interfaces;

namespace TestApp.Controllers
{
    public class ItemsGroupsController : Controller
    {
        private IItemsGroupsService _itemsGroupsService;

        //Default Constructor 
        //Injecting IItemsGroupsService Dependency 
        public ItemsGroupsController(IItemsGroupsService itemsGroupsService)
        {
            _itemsGroupsService = itemsGroupsService; 
        }

        // GET: ItemsGroups
        public ActionResult Index()
        {
            IEnumerable<ItemsGroup> itemsGroups = _itemsGroupsService.GetItemsGroups();
            return View(itemsGroups);
        }

        //Create a new Items Group 
        [HttpGet]
        public ActionResult Create()
        {

            IEnumerable<Item> categories = _itemsGroupsService.GetItemsCategoriesDLL();
            IEnumerable<ItemAttributes> colors = _itemsGroupsService.GetColorsAttributeDDL();

            ViewBag.Categories = categories;
            ViewBag.Colors = colors; 

            return View();
        }

        //Create a new Items Group 
        [HttpPost]
        public ActionResult Create(ItemsGroup group)
        {
            IEnumerable<Item> categories = _itemsGroupsService.GetItemsCategoriesDLL();
            IEnumerable<ItemAttributes> colors = _itemsGroupsService.GetColorsAttributeDDL();

            ViewBag.Categories = categories;
            ViewBag.Colors = colors; 

            if (group.Category == null && group.Size == null && group.Color == null && group.Operator == null)
            {
                ModelState.AddModelError("", "At least one Group Condition is required");
            }

            if (ModelState.IsValid)
            {
                int ret = _itemsGroupsService.CreateItemsGroup(group);

                if (ret >= 1) // Saved Successfully  
                {
                    return RedirectToAction("Index");
                }
                else //Failed 
                {
                    ModelState.AddModelError("", "A error occurred trying to save the data");
                }
            }

            return View(group); 
            
        }

       //Get Sizes By Category Json Result 
        [HttpGet]
        public JsonResult GetSizesByCategory(string categoryName)
        {
            IEnumerable<ItemAttributes> sizes = _itemsGroupsService.GetSizesByCategoryDDL(categoryName);

            return Json(sizes, JsonRequestBehavior.AllowGet); 
        }

        //Editing the selected Item Group 
        [HttpGet]
        public ActionResult Edit(int id)
        {
            IEnumerable<Item> categories = _itemsGroupsService.GetItemsCategoriesDLL();
            IEnumerable<ItemAttributes> colors = _itemsGroupsService.GetColorsAttributeDDL();

            ViewBag.Categories = categories;
            ViewBag.Colors = colors; 

            ItemsGroup group = _itemsGroupsService.GetItemGroupById(id);
            return View(group);
        }

        //Posting the edited Item Group 
        [HttpPost]
        public ActionResult Edit(ItemsGroup group)
        {
            if (ModelState.IsValid)
            {
                _itemsGroupsService.UpdateItemsGroup(group);

                return RedirectToAction("Index");
            }
            else
            {
                return View(group); 
            }
        
        }

        //Posting the edited Item Group 
        [HttpPost]
        public ActionResult Delete(int id)
        {
            _itemsGroupsService.DeleteItemGroup(id);
            return RedirectToAction("Index"); 
        }

        //Get all items under the selected group 
        [HttpGet]
        public ActionResult ItemsList(int id)
        {
            IEnumerable<Item> items = _itemsGroupsService.GetItemsByGroupId(id);

            return View(items); 
        }
         
        //Searching Items Group
        [HttpGet]
        public ActionResult Search(string search)
        {
            IEnumerable<ItemsGroup> items = _itemsGroupsService.Search(search);

            return View("~/Views/ItemsGroups/Index.cshtml", items);
        }

    }
}