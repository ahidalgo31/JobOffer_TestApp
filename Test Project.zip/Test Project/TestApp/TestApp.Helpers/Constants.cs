﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp.Helpers
{
    public static class Constants
    {
        public const string SP_GETITEMS_CATEGORIES = "dbo.SP_GetItemsCategory";
        public const string SP_GETITEMS_GROUPS = "dbo.SP_GetItemsGroups";
        public const string SP_GETSIZES_BY_CATEGORY = "dbo.SP_GetSizesByCategory";
        public const string SP_GETCOLORS_ATTRIBUTE = "dbo.SP_GetColorsAttribute";
        public const string SP_CREATE_ITEMS_GROUPS = "dbo.SP_CreateItemsGroup";
        public const string SP_GETGROUP_BY_ID = "dbo.SP_GetGroupById";
        public const string SP_UPDATE_ITEMS_GROUP = "dbo.SP_UpdateItemsGroup";
        public const string SP_DELETE_ITEMS_GROUP = "dbo.SP_DeleteItemsGroup";
        public const string SP_GET_ITEMS_BY_GROUP = "dbo.SP_GetItemsByGroupId";
        public const string SP_SEARCH_GROUPS = "dbo.SP_GroupsSearch";
    }
}
