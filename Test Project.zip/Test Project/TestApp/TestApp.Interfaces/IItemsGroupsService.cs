﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp.Entities;

namespace TestApp.Interfaces
{
   public interface IItemsGroupsService
   {
       IEnumerable<ItemsGroup> GetItemsGroups();
       IEnumerable<Item> GetItemsCategoriesDLL();
       IEnumerable<ItemAttributes> GetSizesByCategoryDDL(string categoryName);
       IEnumerable<ItemAttributes> GetColorsAttributeDDL();
       int CreateItemsGroup(ItemsGroup group);
       ItemsGroup GetItemGroupById(int id);
       void UpdateItemsGroup(ItemsGroup group);
       void DeleteItemGroup(int id);
       IEnumerable<Item> GetItemsByGroupId(int id);
       IEnumerable<ItemsGroup> Search(string search);
   }
}
