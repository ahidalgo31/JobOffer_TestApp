﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp.Entities;

namespace TestApp.Interfaces
{
    public interface IItemsGroupsRepository
    {
        DataTable GetItemsGroups();
        DataTable GetItemsCategoriesDLL(); 
        DataTable GetSizesByCategoryDDL(string categoryName);
        DataTable GetColorsAttributeDDL();
        int CreateItemsGroup(ItemsGroup group);
        DataTable GetItemGroupById(int id);
        void UpdateItemsGroup(ItemsGroup group);
        void DeleteItemGroup(int id);
        DataTable GetItemsByGroupId(int id);
        DataTable Search(string search); 

    }
}
