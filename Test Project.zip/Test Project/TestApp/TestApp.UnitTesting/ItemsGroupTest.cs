﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestApp.Interfaces;
using Moq;
using TestApp.Entities;
using System.Collections.Generic;
using TestApp.Controllers;
using System.Web.Mvc;

namespace TestApp.UnitTesting
{
    [TestClass]
    public class ItemsGroupTest
    {
        //Testing Index action method in ItemsGroupController which get all ItemsGroup List 
        [TestMethod]
        public void itemgroups_controller_index_should_return_a_list_of_itemsGroups_and_actionresult()
        {
            //Arrange
            var serviceMock = new Mock<IItemsGroupsService>();
            serviceMock.Setup(m => m.GetItemsGroups()).Returns(GetTestItemsGroups()); 
            var controller = new ItemsGroupsController(serviceMock.Object); 
            
            //Act
            var result = controller.Index(); //Calling index action method

            //Assert
            Assert.IsInstanceOfType(result, typeof(ActionResult));
        }

        private List<ItemsGroup> GetTestItemsGroups()
        {
            var group = new List<ItemsGroup>();
            group.Add(new ItemsGroup()
            {
                Id = 1,
                Name = "Test One",
                Description = "test description",
                Category = "test category",
                Size = "test size",
                Color = "test color",
                Operator = "test operator",
                Price = 200


            });
            group.Add(new ItemsGroup()
            {
                Id = 2,
                Name = "Test two",
                Description = "test description two",
                Category = "test category two",
                Size = "test size two",
                Color = "test color two",
                Operator = "test operator two",
                Price = 300
            });
            return group;
        }


        //Testing Create a new Item Group Action Method 
        [TestMethod]
        public void itemgroups_controller_create_should_should_create_a_new_group_and_return_actionresult()
        {
            //Arrange
            var serviceMock = new Mock<IItemsGroupsService>();
            var itemGroupMock = new Mock<ItemsGroup>();
            serviceMock.Setup(m => m.CreateItemsGroup(itemGroupMock.Object)).Returns(1); 
            var controller = new ItemsGroupsController(serviceMock.Object); 
            
            //Act
            var result = controller.Create(); //Calling Create Action Method 

            //Assert
            Assert.IsInstanceOfType(result, typeof(ActionResult));
        }


       /*
        * NOTE: Because of timing constraints, I just added two Unit Testing Method here, 
        * I think the most important thing is to demstrate the understanding of the design pattern.  
       */
        
    }
}
