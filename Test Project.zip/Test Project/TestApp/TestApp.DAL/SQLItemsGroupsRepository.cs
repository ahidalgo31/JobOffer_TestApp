﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp.Entities;
using TestApp.Helpers;
using TestApp.Interfaces;

namespace TestApp.DAL
{
    public class SQLItemsGroupsRepository : IItemsGroupsRepository
    {
        private string _connectionString;
      

        public SQLItemsGroupsRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public DataTable GetItemsGroups()
        {
            return GetData(Constants.SP_GETITEMS_GROUPS, null); 
        }


        public DataTable GetSizesByCategoryDDL(string categoryName)
        {
            List<SqlParameter> listParameters = new List<SqlParameter>();
            listParameters.Add(new SqlParameter("@Category", categoryName));
            return GetData(Constants.SP_GETSIZES_BY_CATEGORY, listParameters);
        }

        public DataTable GetColorsAttributeDDL()
        {
            return GetData(Constants.SP_GETCOLORS_ATTRIBUTE, null); 
        }

        public DataTable GetItemsCategoriesDLL()
        {
            return GetData(Constants.SP_GETITEMS_CATEGORIES, null); 
        }

        private DataTable GetData(string spName, List<SqlParameter> parameters)
        {
            DataTable dt = null;

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();

                    string rtn = spName;
                    SqlCommand cmd = new SqlCommand(rtn, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (parameters != null)
                    {
                        foreach (SqlParameter par in parameters)
                        {
                            cmd.Parameters.Add(par); 
                        }
                    }

                    SqlDataReader rdr = cmd.ExecuteReader();
                    dt = new DataTable();
                    dt.Load(rdr);
                    return dt;

                }
                catch (Exception ex)
                {
                    //logic here to log any exception 
                }
            }
            return dt;
        }

        //Generic method to execute any Stored Procedure 
        private int ExecuteSP(string spName, List<SqlParameter> parameters)
        {
           
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();

                    string rtn = spName;
                    SqlCommand cmd = new SqlCommand(rtn, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (parameters != null)
                    {
                        foreach (SqlParameter par in parameters)
                        {
                            cmd.Parameters.Add(par);
                        }
                    }

                    cmd.ExecuteNonQuery();

                    return 1; 

                }
                catch (Exception ex)
                {
                    //logic here to log any exception 
                }
            }

            return -1;
        }

        public int CreateItemsGroup(ItemsGroup group)
        {
            List<SqlParameter> listParameters = new List<SqlParameter>();
            listParameters.Add(new SqlParameter("@Name", group.Name));
            listParameters.Add(new SqlParameter("@Description", group.Description));
            listParameters.Add(new SqlParameter("@Category", group.Category));
            listParameters.Add(new SqlParameter("@Size", group.Size));
            listParameters.Add(new SqlParameter("@Color", group.Color));
            listParameters.Add(new SqlParameter("@Operator", group.Operator));
            listParameters.Add(new SqlParameter("@Price", group.Price));

            return ExecuteSP(Constants.SP_CREATE_ITEMS_GROUPS, listParameters);
           
        }

        public DataTable GetItemGroupById(int id)
        {
            List<SqlParameter> listParameters = new List<SqlParameter>();
            listParameters.Add(new SqlParameter("@GroupId", id));
            return GetData(Constants.SP_GETGROUP_BY_ID, listParameters);
        }

        //Updating a existing Items Group
        public void UpdateItemsGroup(ItemsGroup group)
        {
            List<SqlParameter> listParameters = new List<SqlParameter>();
            listParameters.Add(new SqlParameter("@Id", group.Id));
            listParameters.Add(new SqlParameter("@Name", group.Name));
            listParameters.Add(new SqlParameter("@Description", group.Description));
            listParameters.Add(new SqlParameter("@Category", group.Category));
            listParameters.Add(new SqlParameter("@Size", group.Size));
            listParameters.Add(new SqlParameter("@Color", group.Color));
            listParameters.Add(new SqlParameter("@Operator", group.Operator));
            listParameters.Add(new SqlParameter("@Price", group.Price));

            ExecuteSP(Constants.SP_UPDATE_ITEMS_GROUP, listParameters);
        }

        public void DeleteItemGroup(int id)
        {
            List<SqlParameter> listParameters = new List<SqlParameter>();
            listParameters.Add(new SqlParameter("@GroupId", id));
            ExecuteSP(Constants.SP_DELETE_ITEMS_GROUP, listParameters);
        }

        public DataTable GetItemsByGroupId(int id)
        {
            List<SqlParameter> listParameters = new List<SqlParameter>();
            listParameters.Add(new SqlParameter("@GroupId", id));
            return GetData(Constants.SP_GET_ITEMS_BY_GROUP, listParameters);
        }

        public DataTable Search(string search)
        {
            List<SqlParameter> listParameters = new List<SqlParameter>();
            listParameters.Add(new SqlParameter("@search", search));
            return GetData(Constants.SP_SEARCH_GROUPS, listParameters);
        }
    }
}
