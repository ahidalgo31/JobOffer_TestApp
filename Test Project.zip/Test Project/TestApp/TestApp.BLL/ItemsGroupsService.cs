﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp.Entities;
using TestApp.Interfaces;

namespace TestApp.BLL
{
    public class ItemsGroupsService: IItemsGroupsService
    {
        private IItemsGroupsRepository _itemsGroupsRepository;

        public ItemsGroupsService(IItemsGroupsRepository itemsGroupsRepository)
        {
            _itemsGroupsRepository = itemsGroupsRepository;
        }
        
        //Get all Items Groups 
        public IEnumerable<ItemsGroup> GetItemsGroups()
        {
            DataTable dt = _itemsGroupsRepository.GetItemsGroups();
            return Helpers.Utility.MapToEntity<ItemsGroup>(dt); 
        }

        public int CreateItemsGroup(ItemsGroup group)
        {
            return _itemsGroupsRepository.CreateItemsGroup(group); 
        }

        public IEnumerable<ItemAttributes> GetSizesByCategoryDDL(string categoryName)
        {
            DataTable dt = _itemsGroupsRepository.GetSizesByCategoryDDL(categoryName);
            return Helpers.Utility.MapToEntity<ItemAttributes>(dt);  
        }

       
        //Get colors to populate DDL
        public IEnumerable<ItemAttributes> GetColorsAttributeDDL()
        {
            DataTable dt = _itemsGroupsRepository.GetColorsAttributeDDL();
            return Helpers.Utility.MapToEntity<ItemAttributes>(dt);  
        }

        public IEnumerable<Item> GetItemsCategoriesDLL()
        {
            DataTable dt = _itemsGroupsRepository.GetItemsCategoriesDLL();
            return Helpers.Utility.MapToEntity<Item>(dt);  
        }

        public ItemsGroup GetItemGroupById(int id)
        {
            DataTable dt = _itemsGroupsRepository.GetItemGroupById(id);

            IEnumerable<ItemsGroup> group =  Helpers.Utility.MapToEntity<ItemsGroup>(dt);

            if (group != null)
            {
                return group.FirstOrDefault();
            }
            else 
            {
                return null; 
            }
        }

        public void UpdateItemsGroup(ItemsGroup group)
        {
            _itemsGroupsRepository.UpdateItemsGroup(group); 
        }

        public void DeleteItemGroup(int id)
        {
            _itemsGroupsRepository.DeleteItemGroup(id); 
        }

        public IEnumerable<Item> GetItemsByGroupId(int id)
        {
            DataTable dt = _itemsGroupsRepository.GetItemsByGroupId(id);
            return Helpers.Utility.MapToEntity<Item>(dt);  
        }

        public IEnumerable<ItemsGroup> Search(string search)
        {
            DataTable dt = _itemsGroupsRepository.Search(search);
            return Helpers.Utility.MapToEntity<ItemsGroup>(dt);  
        }
    }
}
